<label for="jrv">Número de JRV</label>

<select name="jrv" id="jrv" class="form-control" required>
    <option value="">seleccione número de JRV</option>
    <?php $__currentLoopData = $jrvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id_jrv); ?>"><?php echo e($item->junta); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH C:\Users\Luis\Desktop\Proyectos 2024\contadorvotos\resources\views/partials/jrv.blade.php ENDPATH**/ ?>