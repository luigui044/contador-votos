<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="<?php echo e(asset('assets/css/mdb.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">

<?php echo $__env->yieldContent('cssmas'); ?><?php /**PATH C:\Users\Luis Medrano\OneDrive\Documentos\SICE\contadorvotos\resources\views/layouts/styles.blade.php ENDPATH**/ ?>