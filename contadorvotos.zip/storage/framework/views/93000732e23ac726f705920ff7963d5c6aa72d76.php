

<?php $__env->startSection('csrf'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenedor'); ?>
    <div class="container-fluid">

        <h1 class="text-center">Formulario de contador de Votos</h1>
        <hr>
        <form action="<?php echo e(route('guardar')); ?>" id="formulario" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-md-5">

                    <div class="form-group">
                        
                        <label for="centro">Centro de votación</label>
                        <select name="centro" id="centro" class="form-control" required>
                            <option value="">Seleccione centro de votación</option>
                            <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_centro); ?>"><?php echo e($item->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="form-group " id="filtrar">
                        <label for="jrv">Número de JRV</label>
                        <select name="jrv" id="jrv" class="form-control" disabled>
                            <option value="">seleccione número de JRV</option>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6">

                            
                            <div class="form-group">
                                <label for="TPapeletas">Número de Papeletas entregadas</label>
                                <input type="text" name="TPapeletas" class="form-control" id="TPapeletas" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="UPapeletas">Papeletas Utilizadas</label>
                                <input type="text" class="form-control" name="UPapeletas" id="UPapeletas" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="SPapeletas">Papeletas Sobrantes
                                </label>
                                <input type="text" class="form-control" name="SPapeletas" id="SPapeletas" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="IPapeletas">Papeletas inutlizadas
                                </label>
                                <input type="text" class="form-control" name="IPapeletas" id="IPapeletas" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="EPapeletas">Papeletas Entregadas a votantes
                                </label>
                                <input type="text" class="form-control" name="EPapeletas" id="EPapeletas" required>
                            </div>

                        </div>
                        <div class="col-md-6">
                            
                            <div class="form-group">
                                <label for="VValidos">Votos válido</label>
                                <input type="text" name="VValidos" class="form-control" id="VValidos" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="VNulos">Votos nulos</label>
                                <input type="text" class="form-control" name="VNulos" id="VNulos" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="VImpugnados">Votos impugnados
                                </label>
                                <input type="text" class="form-control" name="VImpugnados" id="VImpugnados" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="abstenciones">Abstenciones
                                </label>
                                <input type="text" class="form-control" name="abstenciones" id="abstenciones" required>
                            </div>
                        </div>
                    </div>











                </div>

                <div class="col-md-7">

                    <?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-md-3 form-group">
                                <label for="v<?php echo e($item->id_candidato); ?>">Votos por rostro <?php echo e($item->candidato); ?>

                                </label>
                                <input type="text" class="form-control" name="vCandidato<?php echo e($item->id_candidato); ?>"
                                    id="v<?php echo e($item->id_candidato); ?>" value="0"
                                    onchange="sumar('#v<?php echo e($item->id_candidato); ?>','#vPartido<?php echo e($item->id_candidato); ?>','#vAmbos<?php echo e($item->id_candidato); ?>','#vTotal<?php echo e($item->id_candidato); ?>')"required>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="vpartido<?php echo e($item->id_candidato); ?>">Votos por bandera <?php echo e($item->candidato); ?>

                                </label>
                                <input type="text" class="form-control" name="vPartido<?php echo e($item->id_candidato); ?>"
                                    id="vPartido<?php echo e($item->id_candidato); ?>" value="0"
                                    onchange="sumar('#v<?php echo e($item->id_candidato); ?>','#vPartido<?php echo e($item->id_candidato); ?>','#vAmbos<?php echo e($item->id_candidato); ?>','#vTotal<?php echo e($item->id_candidato); ?>')"required>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="vAmbos<?php echo e($item->id_candidato); ?>">Votos en ambos <?php echo e($item->candidato); ?>

                                </label>
                                <input type="text" class="form-control" name="vAmbos<?php echo e($item->id_candidato); ?>"
                                    id="vAmbos<?php echo e($item->id_candidato); ?>" value="0"
                                    onchange="sumar('#v<?php echo e($item->id_candidato); ?>','#vPartido<?php echo e($item->id_candidato); ?>','#vAmbos<?php echo e($item->id_candidato); ?>','#vTotal<?php echo e($item->id_candidato); ?>')"required>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="vTotal<?php echo e($item->id_candidato); ?>">Total de votos <?php echo e($item->candidato); ?>

                                </label>
                                <input type="text" class="form-control" name="vTotal<?php echo e($item->id_candidato); ?> "
                                    id="vTotal<?php echo e($item->id_candidato); ?>" value="0" disabled>

                                <input type="hidden" name="idcandidato<?php echo e($item->id_candidato); ?>"
                                    value="<?php echo e($item->id_candidato); ?>">
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>

                <button type="submit" class="btn btn-primary  btn-lg btn-block"><i class="fas fa-vote-yea"></i> Guardar
                    Conteo de JRV</button>

        </form>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsmas'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/filt.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Desktop\Proyectos 2024\contadorvotos\resources\views/formulario-votos.blade.php ENDPATH**/ ?>