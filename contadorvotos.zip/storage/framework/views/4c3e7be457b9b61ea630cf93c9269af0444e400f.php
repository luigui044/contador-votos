
<?php $__env->startSection('recarga'); ?>
<meta http-equiv="refresh" content="30">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cssmas'); ?>
    
<style>
    body{
        background-color: #1d2d44;

    }
    #chartdiv{
      width: 100%;
      height: 600px;
      padding-left: 20px;
    }
    #pastel{
        width: 100%;
      height: 450px;
    }
    #podometro,#podometro2{
        width: 100%;
      height: 300px;
    }
    #barra{
        width: 100%;
      height: 300px;
    }
    
    </style>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('contenedor'); ?>

    <div class="row">

        <div class="col-md-4" >
            <div id="chartdiv" ></div>

        </div>
    <div class="col-md-3">
        <div class="row">
            <div class="col-md-12">
                <div id="podometro"></div>

            </div>
            <div class="col-md-12">
                <div id="podometro2"></div>

            </div>
            
        </div>
    </div>
    <div class="col-md-5">
        <div class="row">
            <div class="col-md-12">
                <div id="pastel"></div>
            </div>
            
        </div>
    </div>
    <div class="col-md-6">
            <div id="barra"></div>
    </div>
    </div>


        





<?php $__env->stopSection(); ?>



<?php $__env->startSection('jsmas'); ?>
<script src="<?php echo e(asset('amcharts/core.js')); ?>"></script>
<script src="<?php echo e(asset('amcharts/charts.js')); ?>"></script>
<script src="<?php echo e(asset('amcharts/maps.js')); ?>"></script>
<script src="//www.amcharts.com/lib/4/themes/dark.js"></script>

<script src="<?php echo e(asset('amcharts/themes/animated.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/graficos.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Documents\Proyectos CAOS\contador - copia\resources\views/dashboard-actas.blade.php ENDPATH**/ ?>