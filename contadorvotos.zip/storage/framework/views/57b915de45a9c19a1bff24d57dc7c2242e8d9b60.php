<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=+1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('recarga'); ?>
    <?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<title>Counter 2021</title>
    <?php echo $__env->yieldContent('csrf'); ?>

</head>
<form method="POST" id="salir" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
</form>

    <body>
        <div class="row">
            <?php if(auth()->user()->rol ==1): ?>
                <a href="<?php echo e(route('ingreso')); ?>" target="_blank" class="btn btn-info">Registro de datos</a>
                <a href="<?php echo e(route('dashboard')); ?>" target="_blank"  class="btn btn-info">Gráficos de resultados</a>

            <?php endif; ?>
            <?php if(auth()->user()->rol ==3 || auth()->user()->rol ==1): ?>
                <a href="<?php echo e(route('dashboardActas')); ?>" target="_blank"  class="btn btn-warning">Gráficos de Actas</a>

            <?php endif; ?>
            <?php if(auth()->user()->rol ==1 || auth()->user()->rol ==2): ?>
                
                <a  href="<?php echo e(route('acta')); ?>" target="_blank" class="btn btn-success">Ingresar Acta</a>

            <?php endif; ?>
                



            <button form="salir" type="submit" class="btn btn-danger">Logout</button>

        </div>
            
        <?php echo $__env->yieldContent('contenedor'); ?>
        <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
      </body>












</html><?php /**PATH C:\Users\Luis Medrano\OneDrive\Documentos\SICE\ejemplar a entregar\contadorvotos\resources\views/layouts/master.blade.php ENDPATH**/ ?>