

<?php $__env->startSection('csrf'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenedor'); ?>
    

<div class="container-fluid">
    
    <h1 class="text-center">Formulario de ingreso de actas</h1>
    <hr>
    <form action="<?php echo e(route('guardar2')); ?>" id="formulario" method="POST">
<?php echo csrf_field(); ?>
    <div class="row">

            <div class="col-md-5">

                    <div class="form-group">
                            
                        <label for="centro">Centro de votación</label>
            
                        <select name="centro" id="centro" class="form-control">
                            <option value="">Seleccione centro de votación</option>
                            <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_centro); ?>"><?php echo e($item->nombre); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
            
                    </div>
                    
                    <div class="form-group " id="filtrar">
            
                        <label for="jrv">Número de JRV</label>
            
                        <select name="jrv" id="jrv" class="form-control" disabled>
                            <option value="">seleccione número de JRV</option>
                        </select>
            
                    </div>
            
                    <div class="row">

                        <div class="col-md-6">

                            
                                    <div class="form-group">
                                        <label for="TPapeletas">Número de Papeletas entregadas</label>
                                        <input type="text" name="TPapeletas"  class="form-control" id="TPapeletas" required>
                            
                                    </div>
                            
                            
                            
                                    <div class="form-group">
                                        <label for="UPapeletas">Papeletas Utilizadas</label>
                                        <input type="text" class="form-control" name="UPapeletas" id="UPapeletas" required>
                                    </div>
                                    
                            
                                    <div class="form-group">
                                        <label for="SPapeletas">Papeletas Sobrantes
                                        </label>
                                        <input type="text" class="form-control" name="SPapeletas" id="SPapeletas" required>
                                    </div>
                                
                                <div class="form-group">
                                    <label for="IPapeletas">Papeletas inutlizadas
                                    </label>
                                    <input type="text" class="form-control" name="IPapeletas" id="IPapeletas" required>
                                </div>
                                 
                                 <div class="form-group">
                                    <label for="EPapeletas">Papeletas Entregadas a votantes
                                    </label>
                                    <input type="text" class="form-control" name="EPapeletas" id="EPapeletas" required>
                                </div>
                                    
                        </div>

                        <div class="col-md-6">

                            
                                    <div class="form-group">
                                        <label for="VValidos">Votos válido</label>
                                        <input type="text" name="VValidos"  class="form-control" id="VValidos" required>
                            
                                    </div>
                            
                            
                            
                                    <div class="form-group">
                                        <label for="VNulos">Votos nulos</label>
                                        <input type="text" class="form-control" name="VNulos" id="VNulos" required>
                                    </div>
                                    
                            
                                    <div class="form-group">
                                        <label for="VImpugnados">Votos impugnados
                                        </label>
                                        <input type="text" class="form-control" name="VImpugnados" id="VImpugnados" required>
                                    </div>
                                    
                             <div class="form-group">
                                <label for="abstenciones">Abstenciones
                                </label>
                                <input type="text" class="form-control" name="abstenciones" id="abstenciones" required>
                            </div>
                        </div>
                       
                    </div>
            
            </div>

            <div class="col-md-7">
                
                <div class="row">
                    <div class="col-md-3">
                         
                         <div class="form-group">
                            <label for="vMiguel">Votos Miguel Pereira 
                            </label>
                            <input type="text" class="form-control" name="vMiguel" id="vMiguel" value="0" onchange="sumar('#vMiguel','#vFmln','#vAmbosFmln','#vTotalFmln')"required>
                        </div>
                    </div>
                    <div class="col-md-3">
                         
                        <div class="form-group">
                           <label for="vFmln">Votos FMLN 
                           </label>
                           <input type="text" class="form-control" name="vFmln" id="vFmln"  value="0"  onchange="sumar('#vMiguel','#vFmln','#vAmbosFmln','#vTotalFmln')" required>
                       </div>
                   </div>
                   <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vAmbosFmln">Ambos
                       </label>
                       <input type="text" class="form-control" name="vAmbosFmln" id="vAmbosFmln"  value="0"  onchange="sumar('#vMiguel','#vFmln','#vAmbosFmln','#vTotalFmln')" required>
                   </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vTotalFmln">Total 
                           </label>
                           <input type="text" class="form-control" name="vTotalFmln" id="vTotalFmln" disabled>
                       </div>
                    </div>
                  
                </div>
                
                <div class="row">
                    <div class="col-md-3">
                         
                         <div class="form-group">
                            <label for="vWill">Votos Will Salgado 
                            </label>
                            <input type="text" class="form-control" name="vWill" id="vWill" onchange="sumar('#vWill','#vGanaNi','#vAmbosGanaNi','#vTotalGanaNi')"  value="0"   required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vGanaNi">Votos GANA/NI 
                           </label>
                           <input type="text" class="form-control" name="vGanaNi" id="vGanaNi" onchange="sumar('#vWill','#vGanaNi','#vAmbosGanaNi','#vTotalGanaNi')"  value="0"  required>
                       </div>
                   </div>
                   <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vAmbosGanaNi">Ambos
                       </label>
                       <input type="text" class="form-control" name="vAmbosGanaNi" id="vAmbosGanaNi" onchange="sumar('#vWill','#vGanaNi','#vAmbosGanaNi','#vTotalGanaNi')"  value="0"  required>
                   </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vTotalGanaNi">Total 
                           </label>
                           <input type="text" class="form-control" name="vTotalGanaNi" id="vTotalGanaNi" disabled>
                       </div>
                    </div>
                  
                </div>
                
                <div class="row">
                    <div class="col-md-3">
                         
                         <div class="form-group">
                            <label for="vLuwin">Votos Luwing Campos
                            </label>
                            <input type="text" class="form-control" name="vLuwin" id="vLuwin" onchange="sumar('#vLuwin','#vNT','#vAmbosNT','#vTotalNT')"  value="0"   required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vNT">Votos NT
                           </label>
                           <input type="text" class="form-control" name="vNT" id="vNT" onchange="sumar('#vLuwin','#vNT','#vAmbosNT','#vTotalNT')"  value="0"    required>
                       </div>
                   </div>
                   <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vAmbosNT">Ambos
                       </label>
                       <input type="text" class="form-control" name="vAmbosNT" id="vAmbosNT" onchange="sumar('#vLuwin','#vNT','#vAmbosNT','#vTotalNT')"  value="0"   required>
                   </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vTotalNT">Total 
                           </label>
                           <input type="text" class="form-control" name="vTotalNT" id="vTotalNT" disabled>
                       </div>
                    </div>
                  
                </div>
                
                <div class="row">
                    <div class="col-md-3">
                         
                         <div class="form-group">
                            <label for="vMargarita">Votos  Margarita Moreno 
                            </label>
                            <input type="text" class="form-control" name="vMargarita" id="vMargarita" onchange="sumar('#vMargarita','#vPCN','#vAmbosPCN','#vTotalPCN')"  value="0"   required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vPCN">Votos PCN
                           </label>
                           <input type="text" class="form-control" name="vPCN" id="vPCN" onchange="sumar('#vMargarita','#vPCN','#vAmbosPCN','#vTotalPCN')"  value="0"  required>
                       </div>
                   </div>
                   <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vAmbosPCN">Ambos
                       </label>
                       <input type="text" class="form-control" name="vAmbosPCN" id="vAmbosPCN" onchange="sumar('#vMargarita','#vPCN','#vAmbosPCN','#vTotalPCN')"  value="0"  required>
                   </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vTotalPCN">Total 
                           </label>
                           <input type="text" class="form-control" name="vTotalPCN" id="vTotalPCN"   disabled>
                       </div>
                    </div>



                  
                  
                </div>
                
                <div class="row">
                    <div class="col-md-3">
                         
                         <div class="form-group">
                            <label for="vReyes">Votos Moises Juárez
                            </label>
                            <input type="text" class="form-control" name="vReyes" id="vReyes" onchange="sumar('#vReyes','#vPDC','#vAmbosPDC','#vTotalPDC')"  value="0"  required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vPDC">Votos PDC
                           </label>
                           <input type="text" class="form-control" name="vPDC" id="vPDC" onchange="sumar('#vReyes','#vPDC','#vAmbosPDC','#vTotalPDC')"  value="0" required>
                       </div>
                   </div>
                   <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vAmbosPDC">Ambos
                       </label>
                       <input type="text" class="form-control" name="vAmbosPDC" id="vAmbosPDC" onchange="sumar('#vReyes','#vPDC','#vAmbosPDC','#vTotalPDC')"  value="0" required>
                   </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vTotalPDC">Total 
                           </label>
                           <input type="text" class="form-control" name="vTotalPDC" id="vTotalPDC" disabled>
                       </div>
                    </div>
                   
                  
                </div>
                
                <div class="row">
                    <div class="col-md-3">
                         
                         <div class="form-group">
                            <label for="vGeovanni">Votos Geovanni Flores
                            </label>
                            <input type="text" class="form-control" name="vGeovanni" id="vGeovanni" onchange="sumar('#vGeovanni','#vCD','#vAmbosCD','#vTotalCD')"  value="0" required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vCD">Votos CD
                           </label>
                           <input type="text" class="form-control" name="vCD" id="vCD" onchange="sumar('#vGeovanni','#vCD','#vAmbosCD','#vTotalCD')" value="0"  required>
                       </div>
                   </div>
                   <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vAmbosCD">Ambos
                       </label>
                       <input type="text" class="form-control" name="vAmbosCD" id="vAmbosCD" onchange="sumar('#vGeovanni','#vCD','#vAmbosCD','#vTotalCD')" value="0" required>
                   </div>
                    </div>
                    <div class="col-md-3">
                        
                        <div class="form-group">
                           <label for="vTotalCD">Total 
                           </label>
                           <input type="text" class="form-control" name="vTotalCD" id="vTotalCD" disabled>
                       </div>
                    </div>
                  
                </div>
               
               <div class="row">
                <div class="col-md-3">
                     
                     <div class="form-group">
                        <label for="vMariaViera">Votos Margarita Viera
                        </label>
                        <input type="text" class="form-control" name="vMariaViera" id="vMariaViera" onchange="sumar('#vMariaViera','#vArena','#vAmbosArena','#vTotalArena')" value="0"  required>
                    </div>
                </div>
                <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vArena">Votos ARENA
                       </label>
                       <input type="text" class="form-control" name="vArena" id="vArena" onchange="sumar('#vMariaViera','#vArena','#vAmbosArena','#vTotalArena')" value="0"  required>
                   </div>
               </div>
               <div class="col-md-3">
                
                <div class="form-group">
                   <label for="vAmbosArena">Ambos
                   </label>
                   <input type="text" class="form-control" name="vAmbosArena" id="vAmbosArena" onchange="sumar('#vMariaViera','#vArena','#vAmbosArena','#vTotalArena')" value="0"  required>
               </div>
                </div>
                <div class="col-md-3">
                    
                    <div class="form-group">
                       <label for="vTotalArena">Total 
                       </label>
                       <input type="text" class="form-control" name="vTotalArena" id="vTotalArena" disabled>
                   </div>
                </div>
              
            </div>

            </div>

    </div>
   
    <button type="submit"  class="btn btn-primary  btn-lg btn-block"><i class="fas fa-vote-yea"></i>  Guardar Conteo de JRV</button>

</form>
    

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsmas'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/js/filt2.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Documents\Proyectos CAOS\contador - copia\resources\views/formulario-acta.blade.php ENDPATH**/ ?>